/*
 * file_operations.h
 *
 *  Created on: 2016.11
 *      Author: Leo
 */

#ifndef FILE_OPERATIONS_H_
#define FILE_OPERATIONS_H_
#include "g_net_global.h"

int read_file_to_buff(char *file_path, unsigned long len, char *data);


#endif /* FILE_OPERATIONS_H_ */
