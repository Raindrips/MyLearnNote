/*
 * g_net_update.h
 *
 *  Created on: 
 *      Author: leo
 */

#ifndef G_NET_UPDATE_H_
#define G_NET_UPDATE_H_
#include "g_net_global.h"

CONFIG_INFO *get_config_info(void);
#endif /* G_NET_UPDATE_H_ */
