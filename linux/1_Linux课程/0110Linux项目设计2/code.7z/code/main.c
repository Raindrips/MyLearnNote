

int main(int argc ,char *argv[])
{
    db_list_pt iot_gate = proxy_list_create();
    init_proxy_tcp
    init_proxy_http
    init_proxy_udp
    init_proxy_uart
}
